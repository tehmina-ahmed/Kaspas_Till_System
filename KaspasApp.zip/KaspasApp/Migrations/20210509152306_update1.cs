﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace KaspasApp.Migrations
{
    public partial class update1 : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_Products_Products_productID",
                table: "Products");

            migrationBuilder.DropForeignKey(
                name: "FK_Toppings_Toppings_toppingsID",
                table: "Toppings");

            migrationBuilder.DropIndex(
                name: "IX_Toppings_toppingsID",
                table: "Toppings");

            migrationBuilder.DropIndex(
                name: "IX_Products_productID",
                table: "Products");

            migrationBuilder.DropColumn(
                name: "toppingsID",
                table: "Toppings");

            migrationBuilder.DropColumn(
                name: "productID",
                table: "Products");

            migrationBuilder.CreateIndex(
                name: "IX_Toppings_ProductID",
                table: "Toppings",
                column: "ProductID");

            migrationBuilder.AddForeignKey(
                name: "FK_Toppings_Products_ProductID",
                table: "Toppings",
                column: "ProductID",
                principalTable: "Products",
                principalColumn: "ID",
                onDelete: ReferentialAction.Cascade);
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_Toppings_Products_ProductID",
                table: "Toppings");

            migrationBuilder.DropIndex(
                name: "IX_Toppings_ProductID",
                table: "Toppings");

            migrationBuilder.AddColumn<int>(
                name: "toppingsID",
                table: "Toppings",
                type: "int",
                nullable: true);

            migrationBuilder.AddColumn<int>(
                name: "productID",
                table: "Products",
                type: "int",
                nullable: true);

            migrationBuilder.CreateIndex(
                name: "IX_Toppings_toppingsID",
                table: "Toppings",
                column: "toppingsID");

            migrationBuilder.CreateIndex(
                name: "IX_Products_productID",
                table: "Products",
                column: "productID");

            migrationBuilder.AddForeignKey(
                name: "FK_Products_Products_productID",
                table: "Products",
                column: "productID",
                principalTable: "Products",
                principalColumn: "ID",
                onDelete: ReferentialAction.Restrict);

            migrationBuilder.AddForeignKey(
                name: "FK_Toppings_Toppings_toppingsID",
                table: "Toppings",
                column: "toppingsID",
                principalTable: "Toppings",
                principalColumn: "ID",
                onDelete: ReferentialAction.Restrict);
        }
    }
}
